# references:
  

  government organizations

  mec -> Ministério da Educação
  "Ministry of Education"

  ipec -> Inteligência em Pesquisa e Consultoria Estratégica
  "Intelligence in Research and Strategic Consulting"



instructions to play:

when the bomb drops, the player will have time to answer as many questions as possible, time is timed by the bomb pavilion
