//
//  Variavel.swift
//  wwdcProject
//
//  Created by Gabriel Rossi on 14/04/23.
//

import Foundation

struct Vars {
    var pontos = 0
}
