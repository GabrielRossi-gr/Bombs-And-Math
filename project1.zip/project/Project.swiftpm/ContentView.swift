import SwiftUI
import SpriteKit
import Foundation



struct ContentView: View {
    let gameScene = SKScene(fileNamed: "GameScene")
    var body: some View {

        VStack {
            if let gameScene{
                SpriteView(scene: gameScene)

            }

        }.ignoresSafeArea()
        .navigationBarBackButtonHidden(true)

    }
}










//enum ColliderType: UInt32 {
//  case Apple = 1
//  case Object = 2
//  case Head = 3
//}
//class NimacaoReturns : SKScene, SKPhysicsContactDelegate {
//  var apple: SKSpriteNode?
//  var head: SKSpriteNode?
//  func randomSpawn() -> Int {
//    let randValue = Int.random(in: 200...250)
//    let signal = [1, -1]
//    let randomSIgnal = signal.randomElement()!
//    let finalValue = randomSIgnal * randValue
//    return finalValue
//  }
//  override func didMove(to view: SKView) {
//    apple = childNode(withName: "bomb") as? SKSpriteNode
//    apple?.physicsBody?.isDynamic = true
//    apple?.physicsBody?.categoryBitMask = ColliderType.Apple.rawValue
//    apple?.physicsBody?.contactTestBitMask = ColliderType.Object.rawValue
//    apple?.physicsBody?.collisionBitMask = ColliderType.Object.rawValue
//    head = childNode(withName: "parede") as? SKSpriteNode
//    head?.physicsBody?.isDynamic = false
//    apple?.physicsBody?.categoryBitMask = ColliderType.Head.rawValue
//    apple?.physicsBody?.contactTestBitMask = ColliderType.Apple.rawValue
//    apple?.physicsBody?.collisionBitMask = ColliderType.Object.rawValue
//    self.physicsWorld.contactDelegate = self
//    let finalValue = randomSpawn()
//    apple?.run(.applyForce(.init(dx: CGFloat(finalValue), dy: 0), duration: 0.9))
//  }
//  func didBegin(_ contact: SKPhysicsContact) {
//    let contactAName = contact.bodyA.node?.name
//    let contactBName = contact.bodyB.node?.name
//    if contactAName == "bomb" || contactBName == "bomb" {
//      if contactAName == "parede" || contactBName == "parede" {
//        print("aaaa")
//        return
//      }
//    }
//  }
//}
//


















        //swiftui
//
//        VStack{
//
//            HStack{
//                Image("BlackBoard").resizable().frame(
//                    width: 380,
//                    height: 230
//                //3269 × 1996
//                ).padding(.trailing, 20)
//
//
//                Image("Hand").resizable().frame(
//                    width: 140,
//                    height: 200
//                //1136 × 2038
//                ).padding(.trailing, 20)
//
//                Image("GrandFather").resizable().frame(
//                    width: 130,
//                    height: 190
//                )
//            }.padding(.bottom, 70)
//
//
//            HStack{
//                Image("Rossi").resizable().frame(
//                    width: 140,
//                    height: 170
//                ).padding(.top, 80)
//                    .padding(.leading, 20)
//                Spacer()
//
//
//                Image("Pizza").resizable().frame(
//                    width: 400,
//                    height: 280
//                )
//                .padding(.trailing, 200)
//            }
//
//        }
